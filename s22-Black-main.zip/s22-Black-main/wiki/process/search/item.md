**Authors:** Brandon Williams, Andrew Cudnik

*Please note the prototype is not currently active*

## Search for an item
1. While logged in, click the search bar at the top of a page.
2. Type in what you want to search for, and hit enter.
3. Entries of items you're looking for will show below.
