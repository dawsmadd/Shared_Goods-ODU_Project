**Authors:** Brandon Williams, Andrew Cudnik

*Please note the prototype is not currently active*

## Search for a renter: Option 1
1. While logged in, from any page, go to the  menu at the top.
2. Click on the menu selection "Your Lending Items"
3. Look at the bottom of the page under the "Requests for Rentals" section
4. Look for and click the user name whom you would like to look at

## Search for a renter: Option 2
1. While logged in, visit the URL, link, or bookmark for any item you have listed
2. Click on the button "View Requests for Rentals" on the page
3. Observe the pop-up menu, with "Requests for Rentals"
4. Look for and click the Renter's user name whom you would like to look at
5. View the Renter's informaton on a new page
