**Authors:** Brandon Williams, Andrew Cudnik

*Please note the prototype is not currently active*

## Search for a renter: Option 1
1. While logged in, from any page, go to the menu at the top
2. Click on the menu selection "Items You Are Renting"
3. Look under either "Requesting to Rent" or "Currently Renting"
4. Look for and click the user whom you would like to look at

## Search for a renter: Option 2
1. While logged in, visit the URL, link, or bookmark for any Item listing you are interested in/renting/hoping to rent
2. Click on the Lender's user name on the listing
3. On the new page, view the Lender's information

