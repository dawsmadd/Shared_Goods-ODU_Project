**Authors:** Andrew Cudnik

*Please note the prototype is not currently active*

## Create an Item listing
1. Make sure you have pictures ready to upload of your Item!
2. While logged in, from any page, go to the menu at the top.
3. Click on the menu selection "Create a listing for a new Item"
4. Fill in the form on the new page to create a new Item listing

**NOTE**: Item name, photograph, and location are **REQUIRED**, but make sure to fill out as much information as possible for a more useful listing!
