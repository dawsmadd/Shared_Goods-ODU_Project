**Authors:** Andrew Cudnik

*Please note the prototype is not currently active*

## Edit a Listing: Option 1
1. While logged in, from any page, go to the menu at the top.
2. Click on the menu selection "Your Lending Items"
3. Look at the list of items at the top of the page under "Listed Items"
4. Find the item you would like to edit
5. Click on the "Edit" button on the right side of the Item's row
6. Fill in or change any of the form on the new page to edit the Item's listing


**NOTE 1**: Item name, photograph, and location are **REQUIRED**, but previous entries may be changed

**NOTE 2**: Item listings may not be changed if the Item is currently lent to a Renter
 

## Edit a Listing: Option 2
1. While logged in, visit the URL for any item you have listed
2. Click on the button "Edit This Listing" at the top of the page, next to the Item's name
3. Fill in or change any of the form on the new page to edit the Item's listing


**NOTE 1**: Item name, photograph, and location are **REQUIRED**, but previous entries may be changed

**NOTE 2**: Item listings may not be changed if the Item is currently lent to a Renter
