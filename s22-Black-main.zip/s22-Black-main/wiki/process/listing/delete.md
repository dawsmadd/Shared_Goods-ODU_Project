**Authors:** Andrew Cudnik

*Please note the prototype is not currently active*

## Delete a Listing: Option 1
1. While logged in, from any page, go to the menu at the top left.
2. Click on the menu selection "Your Lending Items"
3. Look at the list of items at the top of the page under "Listed Items"
4. Find the item you would like to delete
5. Click on the "Delete" button on the right side of the Item's row
6. On the new page, enter your password
7. Click on the "Confirm Delete" button underneath of the password entry box

**NOTE**: Item listings may not be deleted if the Item is currently lent to a Renter
 

## Delete a Listing: Option 2
1. While logged in, visit the URL for any item you have listed
2. Click on the button "Delete This Item" at the top of the page, next to the Item's name and Edit button
3. On the new page, enter your password
4. Click on the "Confirm Delete" button underneath of the password entry box


**NOTE**: Item listings may not be deleted if the Item is currently lent to a Renter
