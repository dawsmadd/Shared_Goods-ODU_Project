**Authors:** Dawson Maddock

*Please note the prototype is not currently active*

## Claim an Item
1. Renter locates/searches the item they wish to rent.
2. Renter selects "Request" button on item listing page to notify lender their item is being requested.
3. Lender accesses request on item and communicates with renter on renting details
4. Lender approves or denies renters request.

### If request is denied
5. Communication between renter and lender end and request is removed.

### If request is approved
5. Renter is potentially linked to third-party payment option.

