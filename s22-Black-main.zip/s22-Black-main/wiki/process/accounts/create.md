**Authors:** Alex Schweich

*Please note the prototype is not currently active*

# Create an account
1. Navigate to the home page at https://cs.odu.edu/~411black/index.html
2. While not logged in to an account, click "Log In" at the top right of the corner on the navigation bar
3. Click the "Create an account" button below the log in form
4. Enter the required information in the following form
5. Submit the form
6. Log in to your brand new account!
