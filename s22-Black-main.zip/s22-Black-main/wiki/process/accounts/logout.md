**Authors:** Brandon Williams

*Please note the prototype is not currently active*

## Log out of your account
1. While you're logged in, click on you account name.
2. Scroll all the way down, and hit log out.
