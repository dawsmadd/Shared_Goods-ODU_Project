**Authors:** Brandon Williams

*Please note the prototype is not currently active*

## Deleting your account
1. Look at the top bar and hit the "delete account" button next to the logout button.
2. Enter your password
3. Hit confirm account deletion
