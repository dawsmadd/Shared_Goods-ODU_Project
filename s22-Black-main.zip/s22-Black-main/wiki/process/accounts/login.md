**Authors:** Alex Schweich

*Please note the prototype is not currently active*

## Log in to an account
1. While not currently logged in, click the "Log in" button at the top right 
2. Enter your login email and password
3. Click submit and you are now logged in to your account!
