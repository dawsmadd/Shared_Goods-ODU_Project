**Authors:** Alex Schweich

# Process
Here you can find a list of the various processes Shared Goods will allow you to perform, and detailed instructions on how to perform them.

## Account Management
- [Create an account](accounts/create.md)
- [Log in](accounts/login.md)
- [Log out](accounts/logout.md)
- [Delete Account](accounts/delete.md)

## Search
- [Search for an item](search/item.md)
- [Search for a renter](search/renter.md)
- [Search for a lender](search/lender.md)

## Listing Items
- [List an item for rent](listing/list.md)
- [Edit a listing](listing/edit.md)
- [Delete a listing](listing/delete.md)

## Renting Items
- [Claim an item to be rented](renting/claim.md)
