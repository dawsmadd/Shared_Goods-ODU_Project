**Authors:** Alex Schweich, Andrew Cudnik

**Algorithm**: An ordered set of instructions recursively applied to transform data input into
processed data output, a mathematical solution, descriptive statistics, internet search
engine result, or predictive text suggestions.

**API**: A set of protocols used by programmers to create applications for a specific
operating system or to interface between the different modules of an application.

**Database**: A comprehensive collection of related data organized for convenient access.

**Git**: Software for tracking changes in any set of files, usually used for coordinating work
among programmers collaboratively developing source code during software development.

**Github**: A provider of Internet hosting for software development and version control using
Git.

**GUI**: Graphical User Interface, a software interface designed to standardize and simplify
the use of computer programs.

**HTML**: HyperText Markup Language, a set of standards, a variety of SGML, used to tag
the elements of a hypertext document. It is the standard protocol for formatting and
displaying documents on the World Wide Web.

**HTTP**: Hypertext Transfer Protocol, the standard protocol for transferring hypertext
documents on the World Wide Web.

**IDE**: Integrated development environment, software for programmers that consolidates
coding, compiling, diagnostic, and debugging tools in a single interface.

**Item**: Anything that someone wants to borrow or wants to let someone borrow that is offered on Shared Goods.

**Javascript**: A high-level computer language used commonly to create interactive
applications over the internet.

**Lender**: A user using the Shared Goods web app wanting to list an item that another user may borrow.

**mySQL**: An open-source relational database management system.

**ODU**: Acronym representing Old Dominion University.

**Python**: A high-level computer language.

**Renter**: A user using the Shared Goods web app wanting to look for and borrow an item from another user.

**Server**: A computer that makes services, as access to data files, programs, and peripheral
devices, available to workstations on a network.

**Sprint**: A short, time-boxed period when a team works to complete a set amount of work.

**UI**: User Interface, the interface features through which users interact with the hardware
and software of computers and other electronic devices.

**Wiki**: A type of webpage that is created and edited by collaborative effort.
