**Authors:** Alex Schweich, Nathan Sustarsic, Dawson Maddock, Brandon Williams

# Shared Goods - Wiki

## Table of Contents

- [Process](process/Process.md)

- [Interface](interface/Interface.md)

- [Glossary](Glossary.md)



## Project Summary
Shared Goods is a product designed to help people who want to rent items that are too expensive for a one off purchase connect with other people who have those items and are looking for ways to turn them into a profit. There are a lot of items that can be expensive to purchase and are a requirement for various tasks, but only need to be utilized once or twice a year. Shared Goods will fill this void, providing an effective and simple communication platform for renters and lenders to arrange meetings, length of rental, and prices.
