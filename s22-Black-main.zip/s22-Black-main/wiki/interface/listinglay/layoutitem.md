**Authors:** Gia Smith, Andrew Cudnik

# Listing Layout
The listing layout is set up to display differently for the User who has listed the Item and all other users:
- Lender Users, who listed the item, will view the item name, photo, description, and location. They will also see buttons to edit the listing, delete the listing, and view all requests for rentals.
- Renter Users or guests can see the listing and view the item name, photo, description, location, and a link to view the Lender's account info.
