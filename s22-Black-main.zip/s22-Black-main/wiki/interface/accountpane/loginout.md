**Authors:** Dawson Maddock

*Please note the prototype is not currently active*

# Log In
1. The user clicks the "Log In" button from one of the Shared Goods pages.
2. The user is prompted to enter their username and password.
3. The user selects "Log In"

  ## Correct Login
4. The User is redirected to the home page.

  ## Incorrect Login
4. The user is prompted "Incorrect email/password, please try again".

# Log Out
1. The user selects the "Log Out" buttom from one of the Shared Goods pages.
2. The user is logged out and redirected to the home page.
