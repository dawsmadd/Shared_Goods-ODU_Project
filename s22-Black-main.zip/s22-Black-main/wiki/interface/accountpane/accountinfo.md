**Authors:** Andrew Cudnik

# It's a button, what does it do?
This button simply takes you to the account info page.

## Page Purpose
This page allows you to view your current account information: First Name, Last Name, User Name, Email, Password, ZipCode, and a link you choose to a preferred payment platform.

*NOTE that the payment platform link does not API in or process payments on this platform at all
