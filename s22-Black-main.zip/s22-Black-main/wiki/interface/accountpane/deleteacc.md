**Authors:** Andrew Cudnik

# It's a button, what does it do?
This button simply takes you to the account deletion page.

## Page Purpose
The entire purpose of this page is simple: Delete you account, if you're sure. All it required is a re-entry of your password, 
and the confirmation by hitting the only button on the page.
