**Authors:** Nathan Sustarsic

*Please note the prototype is not currently active*

# New listing
1. The user clicks the "Create a new listing" button from the Shared Goods menu.
2. The user is prompted to enter the item name, item description, and the rate they wish to rent out the item.
3. The user selects "Post Item Listing".

  ## Required Information is Filled
4. The User is redirected to the home page.

  ## Required Information is not Filled
4. The user is prompted "Required Information is Missing".
