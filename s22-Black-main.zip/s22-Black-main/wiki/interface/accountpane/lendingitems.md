**Authors:** Andrew Cudnik

# It's a button, what does it do?
This button takes you to the page for items you are currently lending to others on Shared Goods.

## Page Purpose
This page has two main functions:
- To view a list of all items you have made available on Shared Goods
- To display all requests for you Items other have made to you
