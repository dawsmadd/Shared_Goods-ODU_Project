**Authors:** Andrew Cudnik

# It's a button, what does it do?
This button takes you to the page for items you are renting from others on Shared Goods
## Page Purpose
This page has two main functions:
- To view a list of all items you have currently agreed to rent on Shared Goods
- To display all requests you have made to rent Items from others on Shared Goods

