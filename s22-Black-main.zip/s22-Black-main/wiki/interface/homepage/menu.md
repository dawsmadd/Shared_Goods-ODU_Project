
**Authors:** Nathan Sustarsic, Andrew Cudnik

*Please note the prototype is not currently active*

# Menu
At the top of any page, a menu will appear. It will always display links to: 
- The user's account page
- The listings of items for rent, "Your Lending Items"
- The items the user is currently renting, "Items You Are Renting"
- The create an item listing page, "Create a Listing for a New Item"
- The delete account page
- as well as a link to log in/log out. 

## Page Purpose
The user can navigate to those diffrent pages of the site from anywhere on the site using the top menu links.
