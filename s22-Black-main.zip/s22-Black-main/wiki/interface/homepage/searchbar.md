**Authors:** Dawson Maddock

*Please note the prototype is not currently active*

# Searchbar
1. The user will input the search terms/keywords they wish to be searched into the searchbar.
2. After clicking "Search", the user is redirected to a page containing the search results.
