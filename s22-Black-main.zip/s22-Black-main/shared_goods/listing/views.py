from django.contrib.auth.models import User
from django.http import Http404
from django.shortcuts import render, redirect
from django.shortcuts import get_object_or_404, render
from django.template import Context
from django.urls import reverse
from django.views.generic import CreateView

from listing.models import Listing, RentalAgreement


def view_listing(request, listing_id):
    try:
        listing = get_object_or_404(Listing, pk=listing_id)
        if request.user == listing.posted_by:
            current_user = True
        else:
            current_user = False
    except Listing.DoesNotExist:
        raise Http404("Listing does not exist")
    return render(request, 'listing/view_listing.html', {'listing': listing, 'title': listing.item_name, 'current_user': current_user})


def view_listing_by_user(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        listings = Listing.objects.filter(posted_by=user)
    except Exception:
        raise Http404(f'Error getting listings for {user_id}')
    return render(request, 'listing/list_listings.html',
                  {'listings': listings,
                   'title': f"{user.first_name} {user.last_name}'s Listings"})


def view_rentals_by_user(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        agreements = RentalAgreement.objects.filter(renter_id=user)
        listings = []
        for agreement in agreements:
            listing = Listing.objects.get(pk=agreement.item_id.pk)
            listings.append(listing)
    except Exception:
        raise Http404(f'Error getting listings for {user_id}')
    return render(request, 'listing/list_listings.html',
                  {'listings': listings,
                   'title': f"{user.first_name} {user.last_name}'s Rentals"})


def create_listing(request):
    if not request.user.is_authenticated:
        return redirect('login')
    if request.method == 'GET':
        return render(request, 'listing/create_listing.html', {'title': 'Create a listing'})
    elif request.method == 'POST':
        new_listing = Listing()
        new_listing.posted_by = request.user
        new_listing.item_name = request.POST['name']
        new_listing.description = request.POST['description']
        new_listing.rent_price = request.POST['price']
        new_listing.location = request.POST['location']
        photo = request.FILES['photo']
        new_listing.photo = photo
        new_listing.save()
        return redirect(f'listing:view_listing', listing_id=new_listing.pk)
    return redirect('dashboard')


def delete_listing(request, listing_id):
    if not request.user.is_authenticated:
        return redirect('login')
    try:
        listing = get_object_or_404(Listing, pk=listing_id)
        if request.user == listing.posted_by:
            listing.delete()
    except Listing.DoesNotExist:
        raise Http404("Listing does not exist")
    return redirect('listing:view_listing_by_user', user_id=request.user.pk)


def edit_listing(request, listing_id):
    if not request.user.is_authenticated:
        return redirect('login')
    try:
        listing = get_object_or_404(Listing, pk=listing_id)
    except Listing.DoesNotExist:
        raise Http404("Listing does not exist")
    if request.method == 'GET':
        return render(request, 'listing/edit_listing.html', {'title': f'Edit {listing.item_name}', 'listing': listing})
    elif request.method == 'POST':
        if request.user == listing.posted_by:
            listing.posted_by = request.user
            listing.item_name = request.POST['name']
            listing.description = request.POST['description']
            listing.location = request.POST['location']
            photo = request.FILES['photo']
            listing.photo = photo
            listing.save()
            return redirect(f'listing:view_listing', listing_id=listing.pk)


def claim_listing(request, listing_id):
    if not request.user.is_authenticated:
        return redirect('login')
    try:
        listing = get_object_or_404(Listing, pk=listing_id)
    except Listing.DoesNotExist:
        raise Http404("Listing does not exist")
    listing.currently_available = False
    listing.save()
    agreement = RentalAgreement()
    agreement.item_id = listing
    agreement.lender_id = listing.posted_by
    agreement.renter_id = request.user
    agreement.save()
    return redirect('dashboard')


def search(request, search_text):
    listings = Listing.objects.filter(item_name__contains=search_text, currently_available=True)
    return render(request, 'listing/list_listings.html',
                  {'listings': listings,
                   'title': f"'{search_text}' Search Result"})
