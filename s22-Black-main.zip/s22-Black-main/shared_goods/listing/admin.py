from django.contrib import admin

from listing.models import Listing, RentalAgreement

admin.site.register(Listing)
admin.site.register(RentalAgreement)
