from django.urls import path


from . import views

app_name = 'listing'
urlpatterns = [
    path('<int:listing_id>/', views.view_listing, name='view_listing'),
    path('users/posts/<int:user_id>/', views.view_listing_by_user, name='view_listing_by_user'),
    path('users/rentals/<int:user_id>/', views.view_rentals_by_user, name='view_rentals_by_user'),
    path('create/', views.create_listing, name='create_listing'),
    path('delete/<int:listing_id>', views.delete_listing, name='delete_listing'),
    path('edit/<int:listing_id>', views.edit_listing, name='edit_listing'),
    path('claim/<int:listing_id>', views.claim_listing, name='claim_listing'),
    path('search/<str:search_text>', views.search, name='search'),
]
