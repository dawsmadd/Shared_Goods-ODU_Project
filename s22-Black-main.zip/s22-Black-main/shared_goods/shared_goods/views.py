from django.shortcuts import render, redirect
from listing.models import Listing


def index(request):
    all_listings = Listing.objects.all().filter(currently_available=True)
    return render(request, 'index.html', {'title': 'Shared Goods', 'listings': all_listings})
